import { useEffect, useState } from 'react';
import { getBooks } from '../api/api';
import BookItem from './BookItem';
import { Book } from '../types';

export default function BookList() {
  const [books,setBooks]=useState<Book[]>([]);

  useEffect(()=>{getBooks().then(setBooks);},[]);

  return (
    <ul>
      {books.map(b=><BookItem key={b._id} book={b}/>)}
    </ul>
  );
}