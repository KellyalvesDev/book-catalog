import { useState } from 'react';
import { addBook } from '../api/api';

export default function BookForm() {
  const [title,setTitle]=useState('');
  const [author,setAuthor]=useState('');
  const [status,setStatus]=useState('Não lido');

  const submit=async(e:any)=>{e.preventDefault(); await addBook({title,author,status}); location.reload();};

  return (
    <form onSubmit={submit}>
      <input placeholder='Título' value={title} onChange={e=>setTitle(e.target.value)} />
      <input placeholder='Autor' value={author} onChange={e=>setAuthor(e.target.value)} />
      <select value={status} onChange={e=>setStatus(e.target.value)}>
        <option>Não lido</option><option>Lido</option>
      </select>
      <button>Adicionar</button>
    </form>
  );
}