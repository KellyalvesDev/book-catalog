import { deleteBook } from '../api/api';
import { Book } from '../types';

export default function BookItem({book}:{book:Book}) {
  return (
    <li>
      <strong>{book.title}</strong> — {book.author} ({book.status})
      <button onClick={()=>{deleteBook(book._id!); location.reload();}}>Excluir</button>
    </li>
  );
}