import axios from 'axios';
import { Book } from '../types';

export const API = 'https://crudcrud.com/api/REPLACE/books';

export const getBooks = async () => (await axios.get(API)).data;
export const addBook = async (b: Book) => (await axios.post(API, b)).data;
export const deleteBook = async (id: string) => axios.delete(API + '/' + id);
